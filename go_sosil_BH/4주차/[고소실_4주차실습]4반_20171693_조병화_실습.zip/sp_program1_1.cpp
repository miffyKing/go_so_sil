#include "my_solver.h"

extern float (*_sp_f)(float);
extern float (*_sp_fp)(float);

/*********************************************
  Newton-Rapson Method
**********************************************/
void sp_program1_1(FILE* fp) {
	float x0, x1;
	int n;

	if (fp == NULL)
		return;
	scanf("%f", &x0);
	fprintf(fp, "newton \n");
	fprintf(fp, "i                   xn1                            |f(xn1)|\n");

	for (n = 0; n < Nmax; n++)
	{
		double r1 = _sp_f(x0);

		fprintf(fp, "%d  %20.18e   %20.18e\n", n, x0, fabs(r1));
		if (DELTA > fabs(r1))
		{
			fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(r1));

			break;
		}
		x1 = x0 - r1 / _sp_fp(x0);
		if (fabs(x1 - x0) < EPSILON)
		{
			fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(r1));

			break;
		}
		x0 = x1;

	}

	fprintf(fp, "\n");
	printf("%20.18e \n", x0);
}

