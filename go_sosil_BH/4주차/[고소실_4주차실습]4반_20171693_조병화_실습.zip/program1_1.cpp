#include "my_solver.h"

extern double (*_f)(double);
extern double (*_fp)(double);

/*********************************************
  Newton-Rapson Method
**********************************************/
void program1_1(FILE* fp) {
	double x0, x1;
	int n;

	if (fp == NULL)
		return;
	scanf("%lf", &x0);
	fprintf(fp, "newton \n");
	fprintf(fp, "i                   xn1                            |f(xn1)|\n");

	for (n = 0; n < Nmax; n++)
	{
		double r1 = _f(x0);

		fprintf(fp, "%d  %20.18e   %20.18e\n", n, x0, fabs(r1));
		if (DELTA > fabs(r1))
		{
			fprintf(fp, "%d  %20.18e   %20.18e\n", n+1, x0, fabs(r1));

			break;
		}
		x1 = x0 - r1 / _fp(x0);
		if (fabs(x1 - x0) < EPSILON)
		{
			fprintf(fp, "%d  %20.18e   %20.18e\n", n+1, x0, fabs(r1));

			break;
		}
		x0 = x1;
		
	}

	fprintf(fp, "\n");
	printf("%20.18e \n", x0);
}
