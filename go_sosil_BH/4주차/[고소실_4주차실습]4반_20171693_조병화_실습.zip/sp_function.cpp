#define _USE_MATH_DEFINES
#include <math.h>

float _sp_f_comp(float x) {
	float spfcomp = log(x) - 1;
	return spfcomp;
}

float _sp_fp_comp(float x) {
	float spfpcomp = 1 / x;
	return spfpcomp;
}
