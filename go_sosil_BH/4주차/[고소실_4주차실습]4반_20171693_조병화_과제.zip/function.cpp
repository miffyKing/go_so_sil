#define _USE_MATH_DEFINES
#include <math.h>
//f1 = x ^ 2 - 4x + 4 - lnx = 0
double _f1(double x) {

	double f1 = pow(x, 2) - 4 * x + 4.0 - log(x);
	return f1;
}

double _fp1(double x) {
	double fp1 = 2 *x - 4.0 - 1/x;
	return fp1;
}
// f2 = x +1 -2sin(PI*x) = 0
double _f2(double x) {
	double f2 = x + 1 - 2 * sin(M_PI * x);
	return f2;
}

double _fp2(double x) {
	double fp2 = 1 - 2 * M_PI * cos(M_PI * x);
	return fp2;
}
// f3 = x^4 -11.0x^3 +42.35x^2 -66.55x +35.1384 = 0
double _f3(double x) {
	double f3 = pow(x, 4) - (11.0 * pow(x, 3)) + (42.35 * pow(x, 2)) - (66.55 * x) + 35.1384;
	return f3;
}

double _fp3(double x) {
	double fp3 = (4.0 * pow(x, 3)) - (33.0 * pow(x, 2)) + 84.7 * x - 66.55;
	return fp3;
}

double _f_sqrt(double x) {
	return x * x - 2.0;
}

double _fp_sqrt(double x) {
	return 2.0 * x;
}

double _f_vehicle(double x) {
	double A = 89 * sin(11.5 * (M_PI / 180));
	double B = 89 * cos(11.5 * (M_PI / 180));
	double C = (49 + 0.5 * 55) * sin(11.5 * (M_PI / 180)) - 0.5 * 55 * tan(11.5 * (M_PI) / 180);
	double E = (49 + 0.5 * 55) * cos(11.5 * (M_PI / 180)) - 0.5 * (55);
	double f_vehi = A * sin(x * (M_PI / 180)) * cos(x * (M_PI / 180)) + B * sin(x * (M_PI / 180)) * sin(x * (M_PI / 180)) - C * cos(x * (M_PI / 180)) - E * sin(x * (M_PI / 180));
	return f_vehi;
}

double _fp_vehicle(double x) {
	double A = 89 * sin(11.5 * (M_PI / 180));
	double B = 89 * cos(11.5 * (M_PI / 180));
	double C = (49 + 0.5 * 55) * sin(11.5 * (M_PI / 180)) - 0.5 * 55 * tan(11.5 * (M_PI) / 180);
	double E = (49 + 0.5 * 55) * cos(11.5 * (M_PI / 180)) - 0.5 * (55);
	double fp_vehi = A * cos(x * (M_PI / 180)) * cos(x * (M_PI / 180)) - A * sin(x * ((M_PI / 180))) * sin(x * ((M_PI / 180))) + 2 * B * sin(x * ((M_PI / 180))) * cos(x * (M_PI / 180)) + C * sin(x * ((M_PI / 180))) - E * cos(x * (M_PI / 180));
	return fp_vehi;
}
//lnx -1
double _f_comp(double x) {
	double fcomp = log(x) - 1;
	return fcomp;
}

double _fp_comp(double x) {
	double fpcomp = 1 / x;
	return fpcomp;
}
