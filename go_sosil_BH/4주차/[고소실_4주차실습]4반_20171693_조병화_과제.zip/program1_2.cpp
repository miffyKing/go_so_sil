#include "my_solver.h"

extern double (*_f)(double);
extern double (*_fp)(double);

/*********************************************
  Secant Method
**********************************************/
void program1_2(FILE* fp) {
	double x0, x1, temp;
	int n;

	if (fp == NULL)
		return;

	scanf("%lf %lf", &x0, &x1);
	fprintf(fp, "secant \n");
	fprintf(fp, "i                   xn1                            |f(xn1)|\n");

	for (n = 0; n < Nmax; n++)
	{
		double r1 = _f(x0);
		double r2 = _f(x1);
		//temp = x0;
		//x1 = x0;

		fprintf(fp, "%d  %20.18e   %20.18e\n", n, x0, fabs(r2));
		if (DELTA > fabs(r2))
		{
			fprintf(fp, "%d  %20.18e   %20.18e\n", n, x0, fabs(r2));
			break;
		}
		temp = x1 - r2 * (x1 - x0)/(r2 - r1);
		
		if (fabs(temp - x1) < EPSILON)
		{
			fprintf(fp, "%d  %20.18e   %20.18e\n", n, x0, fabs(r2));
			break;
		}
		x0 = x1;
		x1 = temp;
	}
	fprintf(fp, "\n");
	printf("%20.18e \n", x0);

}
