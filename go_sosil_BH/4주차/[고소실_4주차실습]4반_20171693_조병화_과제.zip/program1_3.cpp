#include "my_solver.h"

extern double (*_f)(double);
extern double (*_fp)(double);

/*********************************************
  Bisection Method -- HOMEWORK
**********************************************/
void program1_3(FILE *fp)
{
	double a0, b0, x0, x1 , temp;
	int n;
	scanf("%lf %lf", &a0, &b0);
	fprintf(fp, "bisection \n");
	fprintf(fp, "n                   xn1                            |f(xn1)|\n");
	n = 0;
	x0 = DBL_MAX;
	while (1)
	{
		x1 = (a0 + b0) / 2;

		fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(_f(x1)));
		if (_f(a0) * _f(x1) < 0)
		{
			b0 = x1;
		}
		else
		{
			a0 = x1;
		}
		if (DELTA > fabs(_f(x1)))
		{
			fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(_f(x1)));

			break;
		}
		if (fabs( x0 -x1) < EPSILON)
		{
			fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(_f(x1) ));

			break;
		}
		if (n > Nmax)
		{
			fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(_f(x1)));

			break;
		}
		x0 = x1;
		n++;
	}

	fprintf(fp, "\n");
	printf("%20.18e \n", x0);
}