#define _CRT_SECURE_NO_WARNINGS

#include "my_solver.h"

void HW_program3_1_1();
void HW_program3_1_2();

#define SOLNUMS 4
#define MATCOLS SOLNUMS
#define MATROWS SOLNUMS
#define TOLERANCE 0.0000001

double C1, b1;
double get[4][5];

double C2, b2;
double got[4][5];


void hw_fcn3_1_2(int* n, double* x, double* fvec, int* iflag) {
	fvec[0] = pow(x[0] - got[0][0], 2.0) + pow(x[1] - got[0][1], 2.0) + pow(x[2] - got[0][2], 2.0) - pow(C2 * (got[0][4] + x[3] - got[0][3]), 2.0);
	fvec[1] = pow(x[0] - got[1][0], 2.0) + pow(x[1] - got[1][1], 2.0) + pow(x[2] - got[1][2], 2.0) - pow(C2 * (got[1][4] + x[3] - got[1][3]), 2.0);
	fvec[2] = pow(x[0] - got[2][0], 2.0) + pow(x[1] - got[2][1], 2.0) + pow(x[2] - got[2][2], 2.0) - pow(C2 * (got[2][4] + x[3] - got[2][3]), 2.0);
	fvec[3] = pow(x[0] - got[3][0], 2.0) + pow(x[1] - got[3][1], 2.0) + pow(x[2] - got[3][2], 2.0) - pow(C2 * (got[3][4] + x[3] - got[3][3]), 2.0);
}

void HW_fcn3_1(int* n, double* x, double* fvec, double* fjac, int* ldfjac, int* iflag)
{
	// origin function F(x)
	if (*iflag == 1) {
		/********************************/
		fvec[0] = pow(x[0] - get[0][0], 2.0) + pow(x[1] - get[0][1], 2.0) + pow(x[2] - get[0][2], 2.0) - pow(C1 * (get[0][4] + x[3] - get[0][3]), 2.0);
		fvec[1] = pow(x[0] - get[1][0], 2.0) + pow(x[1] - get[1][1], 2.0) + pow(x[2] - get[1][2], 2.0) - pow(C1 * (get[1][4] + x[3] - get[1][3]), 2.0);
		fvec[2] = pow(x[0] - get[2][0], 2.0) + pow(x[1] - get[2][1], 2.0) + pow(x[2] - get[2][2], 2.0) - pow(C1 * (get[2][4] + x[3] - get[2][3]), 2.0);
		fvec[3] = pow(x[0] - get[3][0], 2.0) + pow(x[1] - get[3][1], 2.0) + pow(x[2] - get[3][2], 2.0) - pow(C1 * (get[3][4] + x[3] - get[3][3]), 2.0);
		/********************************/
	}
	// Jacobi matrix J(x)
	else if (*iflag == 2) {
		/********************************/
		fjac[0] = 2.0 * (x[0] - get[0][0]);	fjac[4] = 2.0 * (x[1] - get[0][1]);	fjac[8] = 2.0 * (x[2] - get[0][2]);	fjac[12] = (-2.0) * C1 * C1 * (get[0][4] + x[3] - get[0][3]);
		fjac[1] = 2.0 * (x[0] - get[1][0]);	fjac[5] = 2.0 * (x[1] - get[1][1]);	fjac[9] = 2.0 * (x[2] - get[1][2]);	fjac[13] = (-2.0) * C1 * C1 * (get[1][4] + x[3] - get[1][3]);
		fjac[2] = 2.0 * (x[0] - get[2][0]);	fjac[6] = 2.0 * (x[1] - get[2][1]);	fjac[10] = 2.0 * (x[2] - get[2][2]);	fjac[14] = (-2.0) * C1 * C1 * (get[2][4] + x[3] - get[2][3]);
		fjac[3] = 2.0 * (x[0] - get[3][0]);	fjac[7] = 2.0 * (x[1] - get[3][1]);	fjac[11] = 2.0 * (x[2] - get[3][2]);	fjac[15] = (-2.0) * C1 * C1 * (get[3][4] + x[3] - get[3][3]);
		/********************************/
	}
}


void HW_program3_1()
{
	HW_program3_1_1();
	HW_program3_1_2();
}

void HW_program3_1_1()
{
	//printf("1\n");
	char readfile[256];
	char writefile[256];
	int n = SOLNUMS;
	double x[SOLNUMS];	//need to initilize x0
	double fvec[SOLNUMS], fjac[MATCOLS * MATROWS];
	int ldfjac = SOLNUMS;
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (SOLNUMS + 13)) / 2;
	//double x2[SOLNUMS] = { 1.55, 1.39, 1.10 };
	double fabs_x[SOLNUMS];

	/********************************/

	//hybrj1
	//printf("practice3-1 hybrj1:\n");
	for (int t = 0; t < 3; t++) {
		sprintf(readfile, "GPS_signal_%d.txt", t);
		sprintf(writefile, "GPS_position3-1_%d.txt", t);

		FILE* fp_r = fopen(readfile, "r");
		if (fp_r == NULL) {
			printf("%s file open error...\n", readfile);
			return;
		}
		FILE* fp_w = fopen(writefile, "w");
		if (fp_w == NULL) {
			printf("%s file open error...\n", writefile);
			return;
		}
		fscanf(fp_r, "%lf %lf", &C1, &b1);
		for (int i = 0; i < 4; i++) {
			fscanf(fp_r, "%lf %lf %lf %lf %lf", &get[i][0], &get[i][1], &get[i][2], &get[i][3], &get[i][4]);
		}
		printf("insert 3 coordinates : ");
		scanf("%lf %lf %lf", &x[0], &x[1], &x[2]);
		x[3] = b1;

		fprintf(fp_w, "Initial: %.15lf, %.15lf, %.15lf, %.15f\n", x[0], x[1], x[2], x[3]);

		hybrj1_(HW_fcn3_1, &n, x, fvec, fjac, &ldfjac, &tol, &info, wa, &lwa);

		if (info == 1) {
			fprintf(fp_w, "x1 = %.15lf, x2 = %.15lf, x3 =  %.15lf, x4 = %.15f\n", x[0], x[1], x[2], x[3]);

			fabs_x[0] = pow(x[0] - get[0][0], 2.0) + pow(x[1] - get[0][1], 2.0) + pow(x[2] - get[0][2], 2.0) - pow(C1 * (get[0][4] + x[3] - get[0][3]), 2.0);
			fabs_x[1] = pow(x[0] - get[1][0], 2.0) + pow(x[1] - get[1][1], 2.0) + pow(x[2] - get[1][2], 2.0) - pow(C1 * (get[1][4] + x[3] - get[1][3]), 2.0);
			fabs_x[2] = pow(x[0] - get[2][0], 2.0) + pow(x[1] - get[2][1], 2.0) + pow(x[2] - get[2][2], 2.0) - pow(C1 * (get[2][4] + x[3] - get[2][3]), 2.0);
			fabs_x[3] = pow(x[0] - get[3][0], 2.0) + pow(x[1] - get[3][1], 2.0) + pow(x[2] - get[3][2], 2.0) - pow(C1* (get[3][4] + x[3] - get[3][3]), 2.0);

			fabs_x[0] = fabs(fabs_x[0]);
			fabs_x[1] = fabs(fabs_x[1]);
			fabs_x[2] = fabs(fabs_x[2]);
			fabs_x[3] = fabs(fabs_x[3]);

			fprintf(fp_w, "|f1()| = %.15lf\n", fabs_x[0]);
			fprintf(fp_w, "|f2()| = %.15lf\n", fabs_x[1]);
			fprintf(fp_w, "|f3()| = %.15lf\n", fabs_x[2]);
			fprintf(fp_w, "|f3()| = %.15lf\n", fabs_x[3]);
			fprintf(fp_w, "\n");
		}
		else
			fprintf(fp_w, "Fail\n");

		fclose(fp_r);
		fclose(fp_w);
	}

}

void HW_program3_1_2()
{
	//printf("2\n");
	char readfile[256];
	char writefile[256];
	int n = SOLNUMS;
	double x[SOLNUMS];	//need to initilize x0
	double fvec[SOLNUMS];
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (3 * SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (3 * SOLNUMS + 13)) / 2;
	double fabs_x[SOLNUMS];

	//hybrd1
	printf("practice3-1 hybrd1:\n");
	for (int t = 0; t < 3; t++) {

		sprintf(readfile, "GPS_signal_%d.txt", t);
		sprintf(writefile, "GPS_position3-2_%d.txt", t);

		FILE* fp_r = fopen(readfile, "r");
		if (fp_r == NULL) {
			printf("%s file open error...\n", readfile);
			return;
		}

		FILE* fp_w = fopen(writefile, "w");
		if (fp_w == NULL) {
			printf("%s file open error...\n", writefile);
			return;
		}

		fscanf(fp_r, "%lf %lf", &C2, &b2);
		for (int i = 0; i < 4; i++) {
			fscanf(fp_r, "%lf %lf %lf %lf %lf", &got[i][0], &got[i][1], &got[i][2], &got[i][3], &got[i][4]);
			//printf("%lf %lf\n", got[i][0], got[i][1]);
		}
		printf("insert 4 coordinates :");
		scanf("%lf %lf %lf", &x[0], &x[1], &x[2]);
		x[3] = b2;

		fprintf(fp_w, "Initial: %.15lf, %.15lf, %.15lf, %.15f\n", x[0], x[1], x[2], x[3]);

		hybrd1_(hw_fcn3_1_2, &n, x, fvec, &tol, &info, wa, &lwa);

		//printf("%d\n", info);

		if (info == 1) {
			fprintf(fp_w, "x1 = %.15lf, x2 = %.15lf, x3 =  %.15lf, x4 = %.15f\n", x[0], x[1], x[2], x[3]);

			fabs_x[0] = pow(x[0] - got[0][0], 2.0) + pow(x[1] - got[0][1], 2.0) + pow(x[2] - got[0][2], 2.0) - pow(C2 * (got[0][4] + x[3] - got[0][3]), 2.0);
			fabs_x[1] = pow(x[0] - got[1][0], 2.0) + pow(x[1] - got[1][1], 2.0) + pow(x[2] - got[1][2], 2.0) - pow(C2 * (got[1][4] + x[3] - got[1][3]), 2.0);
			fabs_x[2] = pow(x[0] - got[2][0], 2.0) + pow(x[1] - got[2][1], 2.0) + pow(x[2] - got[2][2], 2.0) - pow(C2 * (got[2][4] + x[3] - got[2][3]), 2.0);
			fabs_x[3] = pow(x[0] - got[3][0], 2.0) + pow(x[1] - got[3][1], 2.0) + pow(x[2] - got[3][2], 2.0) - pow(C2 * (got[3][4] + x[3] - got[3][3]), 2.0);

			fabs_x[0] = fabs(fabs_x[0]);
			fabs_x[1] = fabs(fabs_x[1]);
			fabs_x[2] = fabs(fabs_x[2]);
			fabs_x[3] = fabs(fabs_x[3]);

			fprintf(fp_w, "|f1()| = %.15lf\n", fabs_x[0]);
			fprintf(fp_w, "|f2()| = %.15lf\n", fabs_x[1]);
			fprintf(fp_w, "|f3()| = %.15lf\n", fabs_x[2]);
			fprintf(fp_w, "|f3()| = %.15lf\n", fabs_x[3]);
			fprintf(fp_w, "\n");
		}
		else
			fprintf(fp_w, "Fail\n");


		fclose(fp_r);
		fclose(fp_w);
	}
}