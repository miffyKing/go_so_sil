#define _CRT_SECURE_NO_WARNINGS
#include "my_solver.h"



#define SOLNUMS 2
#define MATCOLS SOLNUMS
#define MATROWS SOLNUMS
#define TOLERANCE 0.0000001


//double C2, b2;
//double got[4][5];

void hw_fcn3_3_1(int* n, double* x, double* fvec, int* iflag) {
	//fvec[0] = ((sin(x[0] * x[1] + M_PI / 6.0) + (sqrt(pow(x[0], 2.0) * pow(x[1], 2.0) + 1))) / cos(x[0] - x[1])) + 2.8;
	//fvec[1] = ((x[0] * exp(x[0] * x[1] + M_PI / 6.0) - sin(x[0] - x[1])) / sqrt(pow(x[0], 2.0) * pow(x[1], 2.0) + 1)) - 1.66;
	fvec[0] = sin(x[0] * x[1] + M_PI / 6.0) + sqrt(pow(x[0], 2) * pow(x[1], 2) + 1) + 2.8 * cos(x[0] - x[1]);
	fvec[1] = x[0] * exp(x[0] * x[1] + M_PI / 6.0) - sin(x[0] - x[1]) - 1.66 * sqrt(pow(x[0], 2) * pow(x[1], 2) + 1);
}
void hw_fcn3_3_2(int* n, double* x, double* fvec, double* fjac, int* ldfjac, int* iflag)
{
	//origin function F(x)
	if (*iflag == 1) {
		/********************************/
		fvec[0] = (sin(x[0] * x[1] + M_PI / 6.0) + (sqrt(pow(x[0], 2.0) * pow(x[1], 2.0) + 1))) / cos(x[0] - x[1]) + 2.8;
		fvec[1] = (x[0] * exp(x[0] * x[1] + M_PI / 6.0) - sin(x[0] - x[1])) / sqrt(pow(x[0], 2.0) * pow(x[1], 2.0) + 1) - 1.66;
		/********************************/
	}
	//Jacobi matrix J(x)
	else if (*iflag == 2) {
		/********************************/
		fjac[0] = ((x[0] * x[1] * x[1]) / sqrt(1 + x[0] * x[0] * x[1] * x[1]) + x[1] * cos(M_PI / 6 - x[0] * x[1])) / (1.0 / cos(x[0] - x[1])) + (1.0/cos(x[0] - x[1])) * (sqrt(1 + x[0] * x[0] * x[1] * x[1]) - sin(M_PI / 6 - x[0] * x[1])) * tan(x[0] - x[1]);
		fjac[1] = (exp(M_PI / 6 + x[0] * x[1]) + exp(M_PI / 6 + x[0] * x[1]) * x[0] * x[1] - cos(x[0] - x[1])) / sqrt(1 + x[0] * x[0] * x[1] * x[1]) - (x[0] * x[1] * x[1] * (exp(M_PI / 6 + x[0] * x[1]) * x[0] - sin(x[0] - x[1]))) / pow((1 + x[0] * x[0] * x[1] * x[1]), ((double)3 / 2));
		fjac[2] = ((x[0] * x[0] * x[1]) / sqrt(1 + x[0] * x[0] * x[1] * x[1]) + x[0] * cos(M_PI / 6 - x[0] * x[1])) * (1.0/cos(x[0] - x[1])) - (1.0 / cos(x[0] - x[1])) * (sqrt(1 + x[0] * x[0] * x[1] * x[1]) - sin(M_PI / 6 - x[0] * x[1])) * tan(x[0] - x[1]);
		fjac[3] = (exp(M_PI / 6 + x[0] * x[1]) * x[0] * x[0] + cos(x[0] - x[1])) / sqrt(1 + x[0] * x[0] * x[1] * x[1]) - (x[0] * x[0] * x[1] * (exp(M_PI / 6 + x[0] * x[1]) * x[0] - sin(x[0] - x[1]))) / pow((1 + x[0] * x[0] * x[1] * x[1]), ((double)3 / 2));


		/********************************/
	}
}

void HW_program3_3_1();
void HW_program3_3_2();

void HW_program3_3()
{

	HW_program3_3_1();
	//HW_program3_3_2();


}
void HW_program3_3_1()
{

	int n = SOLNUMS;
	double x[SOLNUMS] = { 20.0, 0.0 };	//need to initilize x0
	double fvec[SOLNUMS], fjac[MATCOLS * MATROWS];
	int ldfjac = SOLNUMS;
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (15*SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (15*SOLNUMS + 13)) / 2;
	double fabs_x[SOLNUMS];

	FILE* fp_w = fopen("roots_found_3-3.txt", "w");
	if (fp_w == NULL) {
		printf("%s file open error...\n", "roots_3-5.txt");
		return;
	}

	//hybrd1
	hybrd1_(hw_fcn3_3_1, &n, x, fvec, &tol, &info, wa, &lwa);
	
		fprintf(fp_w, "%d %lf %lf\n", info, x[0], x[1]);

		fvec[0] = sin(x[0] * x[1] + M_PI / 6.0) + sqrt(pow(x[0], 2) * pow(x[1], 2) + 1) + 2.8 * cos(x[0] - x[1]);
		fvec[1] = x[0] * exp(x[0] * x[1] + M_PI / 6.0) - sin(x[0] - x[1]) - 1.66 * sqrt(pow(x[0], 2) * pow(x[1], 2) + 1);

		fabs_x[0] = fabs(fabs_x[0]);
		fabs_x[1] = fabs(fabs_x[1]);

		fprintf(fp_w, "|f1()| = %lf\n", fabs_x[0]);
		fprintf(fp_w, "|f2()| = %lf\n", fabs_x[1]);
		fprintf(fp_w, "\n");
	
	/********************************/
	fclose(fp_w);
	
}

void HW_program3_3_2(void) {
	int n = SOLNUMS;
	double x[SOLNUMS] = { 20.0, 0.0 };	//need to initilize x0
	double fvec[SOLNUMS], fjac[MATCOLS * MATROWS];
	int ldfjac = SOLNUMS;
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (15* SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (15* SOLNUMS + 13)) / 2;
	double fabs_x[SOLNUMS];

	FILE* fp_w = fopen("roots_found_3-3.txt", "w");
	if (fp_w == NULL) {
		printf("%s file open error...\n", "roots_3-5.txt");
		return;
	}

	/********************************/

	hybrj1_(hw_fcn3_3_2, &n, x, fvec, fjac, &ldfjac, &tol, &info, wa, &lwa);

	fprintf(fp_w, "%d %lf %lf\n", info, x[0], x[1]);

	fabs_x[0] = (sin(x[0] * x[1] + M_PI / 6.0) + (sqrt(x[0]*x[0] * x[1]* x[1] + 1))) / cos(x[0] - x[1]) + 2.8;
	fabs_x[1] = (x[0] * exp(x[0] * x[1] + M_PI / 6.0) - sin(x[0] - x[1])) / sqrt(x[0]*x[0] * x[1]*x[1] + 1) - 1.66;

	fabs_x[0] = fabs(fabs_x[0]);
	fabs_x[1] = fabs(fabs_x[1]);


	fprintf(fp_w, "|f1()| = %lf\n", fabs_x[0]);
	fprintf(fp_w, "|f2()| = %lf\n", fabs_x[1]);

	fprintf(fp_w, "\n");


	/********************************/

	fclose(fp_w);
}
