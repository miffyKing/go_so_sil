﻿#include "my_solver.h"

int main(void)
{
   /*practice3_1();
    practice3_2();
   practice3_3();
    practice3_4();
    practice3_5();
    practice3_6();
    practice3_7();
    practice3_8();*/
    
    HW_program3_1();
    HW_program3_2();
    HW_program3_3();
    HW_program3_4();

    return 0;
}
