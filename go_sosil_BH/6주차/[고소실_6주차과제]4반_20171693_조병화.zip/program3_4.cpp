#define _CRT_SECURE_NO_WARNINGS
#include "my_solver.h"



#define SOLNUMS 2
#define MATCOLS SOLNUMS
#define MATROWS SOLNUMS
#define TOLERANCE 0.0000001

void HW_program3_4()
{
	FILE* fp_r = fopen("linear_system_3-4.txt", "r");
	FILE* fp_w = fopen("solution_3-4.txt", "w");

	int n, i, j, ia, * l;

	float temp, * a, * b, * x, * s, * vari;

	fscanf(fp_r, "%d", &n);

	a = (float*)malloc(sizeof(float*) * n * n);
	b = (float*)malloc(sizeof(float) * n);
	float *a_tmp = (float*)malloc(sizeof(float*) * n * n);
	float *b_tmp = (float*)malloc(sizeof(float) * n);
	x = (float*)malloc(sizeof(float) * n);
	s = (float*)malloc(sizeof(float) * n);
	vari = (float*)malloc(sizeof(float) * n);
	l = (int*)malloc(sizeof(int) * n);
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			fscanf(fp_r, "%f", &a[j * n + i]);
			a_tmp[j * n + i] = a[j * n + i];

		}
	}

	for (i = 0; i < n; i++) {
		fscanf(fp_r, "%f", &b[i]);
		b_tmp[i] = b[i];
	}
	ia = n;

	gespp_(&n, a, &ia, l, s);
	solve_(&n, a, &ia, l, b, x);

	fprintf(fp_w, "%d\n", n);

	for (i = 0; i < n; i++)
		fprintf(fp_w, "%f\n", x[i]);


	fclose(fp_r);
	fp_r = fopen("linear_system_3-4.txt", "r");

	fscanf(fp_r, "%d", &n);
	double tmp2 = 0;
	double b_sum = 0;
	for (i = 0; i < n; i++) {
		temp = 0;
		for (j = 0; j < n; j++) {
			temp = temp + a_tmp[n * j + i] * x[j];

		}
		temp = temp - b_tmp[i];
		tmp2 += pow(temp,2);
		//temp = fabs(temp);
		//temp = temp / (b_tmp[i]*b_tmp[i]);
		//vari[i] = temp;
		b_sum += b_tmp[i] * b_tmp[i];
	}
	double result = sqrt(tmp2) / sqrt(b_sum);
	
	/*
//	temp = 0;
	for (i = 0; i < n; i++) {
		temp += vari[i];
	}
	temp /= n;*/
	fprintf(fp_w, "difference : %f\n", result);
	
	/*
	float sum = 0.0, pow_sum = 0.0, pow_sum2 = 0.0, result_e = 0.0;

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			sum += a[n*j+i] * x[j];
		}
		sum -= b[i];
		pow_sum += sum * sum;
		sum = 0.0;
	}
	for (int i = 0; i < n; i++) {
		pow_sum2 += b[i] * b[i];
	}
	result_e = sqrt(pow_sum) / sqrt(pow_sum2);  
	*/
}