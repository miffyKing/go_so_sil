#include <stdio.h>
#include <string.h>
#include <random>
#include <time.h>

#include <math.h>
#include <time.h>
#include <Windows.h>

__int64 start, freq, end;
#define CHECK_TIME_START QueryPerformanceFrequency((LARGE_INTEGER*)&freq); QueryPerformanceCounter((LARGE_INTEGER*)&start)
#define CHECK_TIME_END(a) QueryPerformanceCounter((LARGE_INTEGER*)&end); a = (float)((float)(end - start) / (freq / 1000.0f))
float compute_time;
float compute_time1, compute_time2;

#define ARRAY_SIZE 100000
#define TWO_23 (1 << 15)
#define MATDIM 1024
#define HW1_N 1000

float *hw1_x, hw1_E, hw1_var1, hw1_var2;
float hw2_a, hw2_b, hw2_c, hw2_naive_ans[2], hw2_pre_ans[2];

/* hw1 */
void init_hw1(int fixed);
void hw1_calc_e();
void hw1_calc_var1();
void hw1_calc_var2();
/* hw2 */
void hw2_naive();
void hw2_safe();
float hw2_verify(float x);
/* hw3 */
void Loop_Invariant_Code_Motion();
void Strength_Reduction();
void Binary_Breakdown();
void Loop_Inversion();
void Local_Global();
void eliminating_sub_expressions();
float Glob[ARRAY_SIZE];

void main(void)
{
	srand((unsigned)time(NULL));
	/* hw1 */
	
	puts("====== hw1 ======");
	init_hw1(1);
	hw1_calc_e();

	CHECK_TIME_START;
	
	
	hw1_calc_var1();

	CHECK_TIME_END(compute_time);
	compute_time1 = compute_time;
	printf("hw1_calc_var1 = %f ms\n", compute_time);
	printf("hw1_calc_var1 value = %.15f\n", hw1_var1);
//	compute_time = 0;

	CHECK_TIME_START;
	hw1_calc_var2();
	CHECK_TIME_END(compute_time);
	compute_time2 = compute_time;
	printf("hw1_calc_var2 = %f ms\n", compute_time);
	printf("hw1_calc_var2 value = %.15f\n", hw1_var2);
	puts("");
	
	/* hw2 */
	/*
	puts("====== hw2 ======");
	printf("a, b, c : ");
	scanf("%f %f %f", &hw2_a, &hw2_b, &hw2_c);
	hw2_naive();
	hw2_safe();
	printf("naive result    : %.15f, %.15f\n", hw2_naive_ans[0], hw2_naive_ans[1]);
	printf("advanced result : %.15f, %.15f\n", hw2_pre_ans[0], hw2_pre_ans[1]);
	puts("");
	printf("Verifying naive ans    : %.15f, %.15f\n", hw2_verify(hw2_naive_ans[0]), hw2_verify(hw2_naive_ans[1]));
	printf("Verifying advanced ans : %.15f, %.15f\n", hw2_verify(hw2_pre_ans[0]), hw2_verify(hw2_pre_ans[1]));
	puts("");
	*/
	/* hw3 */
	/*
	Loop_Invariant_Code_Motion();
	Strength_Reduction();
	Binary_Breakdown();


	Local_Global();
	Loop_Inversion();
	eliminating_sub_expressions();
	*/
}

void init_hw1(int fixed)
{
	float* ptr;
	hw1_x = (float*)malloc(sizeof(float) * HW1_N);

	if (fixed)
	{
		float tmp = HW1_N;
		for (int i = 0; i < HW1_N; i++)
		{
			if (i & 1) tmp -= 0.0001;
			hw1_x[i] = tmp;
		}
	}
	else
	{
		srand((unsigned)time(NULL));
		ptr = hw1_x;
		for (int i = 0; i < HW1_N; i++)
			*ptr++ = ((float)rand() / (float)RAND_MAX) * 2;
	}
}

void hw1_calc_e()
{
	hw1_E = 0.0;
	for (int i = 0; i < HW1_N; i++) {
		hw1_E += hw1_x[i];
	}
	hw1_E = hw1_E/HW1_N;
}
void hw1_calc_var1()
{
	double sum = 0;
	for (int i = 0; i < HW1_N; i++)
		sum = sum + (hw1_x[i] - hw1_E) * (hw1_x[i] - hw1_E);
	sum = sum / (HW1_N - 1);
	hw1_var1 = sum;

	if (hw1_var1 < 0)
	{
		printf("variant cannot be minus.  ERROR happened 1 \n");
	}
}
void hw1_calc_var2()
{
	float tmp1 = 0.0, tmp2 = 0.0, result = 0.0;

	for (int i = 0; i < HW1_N; i++) {
		tmp1 += hw1_x[i] * hw1_x[i];
		tmp2 += hw1_x[i];
	}
	if (tmp1 < 0)
	{
		printf("1\n");
	}

	result = HW1_N * tmp1 - tmp2 * tmp2;
	/*
	if (HW1_N * tmp1 <  tmp2*tmp2)
	{
		printf("%lf %lf %lf %lf\n", tmp1, tmp2, tmp1 * HW1_N, tmp2 * tmp2);
		printf("%d\n", strlen("100000000100000000001011000000000000000000000"));
		printf("2\n");
	}*/
	hw1_var2 = (result) / (HW1_N * (HW1_N - 1));
	if (hw1_var2 < 0)
	{
		printf("variant cannot be minus.  ERROR happened 2 \n");
	}
}


/* hw2 */
void hw2_naive()
{
	float ans_1 = 0, ans_2 = 0;
	ans_1 = (-hw2_b + sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c)) / (2 * hw2_a);
	ans_2 = (-hw2_b - sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c)) / (2 * hw2_a);

	hw2_naive_ans[0] = ans_1;
	hw2_naive_ans[1] = ans_2;
}
void hw2_safe()
{
	double ans_1 = 0, ans_2 = 0;

	if (hw2_b >= 0) {
		ans_1 = (-4) * hw2_a * hw2_c;
		ans_1 = ans_1 / (hw2_b + sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c));
		ans_1 = ans_1 / (2 * hw2_a);

		ans_2 = (-hw2_b) - sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c);
		ans_2 = ans_2 / (2 * hw2_a);

	}

	else {

		ans_1 = (-hw2_b) + sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c);
		ans_1 = ans_1 / (2 * hw2_a);
		ans_2 = (-4) * hw2_a * hw2_c;
		ans_2 = ans_2 / (hw2_b - sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c));
		ans_2 = ans_2 / 2 * hw2_a;

	}


	hw2_pre_ans[0] = ans_1;
	hw2_pre_ans[1] = ans_2;

}
float hw2_verify(float x)
{
	return hw2_a * x * x + hw2_b*x + hw2_c;
}

void Loop_Invariant_Code_Motion() {
	int Array[ARRAY_SIZE];

	int v1, v2, v3, v4, temp;
	float run_time;
	printf("\n*****************************\n");
	printf("*Loop Invariant Code Motion *\n");
	printf("*****************************\n");
	srand(time(NULL));
	v1 = rand() / 165;
	v2 = rand() / 165;
	v3 = rand() / 165;
	v4 = rand() / 165;

	CHECK_TIME_START;
	for (int i = 0; i < ARRAY_SIZE; i++) {
		Array[i] = (v1 * v1) + (v2 * v2) + (v3 * v3) + (v4 * v4) + ARRAY_SIZE + i;
	}

	CHECK_TIME_END(run_time);
	printf("The runtime before using loop invarient cod motion is %.3f(ms).\n", run_time * 1000);

	CHECK_TIME_START;
	temp = (v1 * v1) + (v2 * v2) + (v3 * v3) + (v4 * v4) + ARRAY_SIZE;
	for (int i = 0; i < ARRAY_SIZE; i++) {
		Array[i] = temp + 1;
	}

	CHECK_TIME_END(run_time);
	printf("The runtime after using loop invarient cod motion is %.3f(ms).\n", run_time * 1000);

}

void Strength_Reduction() {
	int Array[ARRAY_SIZE];
	float run_time;
	printf("\n\n*****************************\n");
	printf("*   Strength Reduction      *\n");
	printf("*****************************\n");
	srand(time(NULL));
	for (int i = 0; i < ARRAY_SIZE; i++) {
		Array[i] = rand() % 1653;
	}

	CHECK_TIME_START;
	for (int i = 0; i < ARRAY_SIZE; i++) {
		Array[i] = i * 64 / 64 * 64 / 64 * 64 / 64 * 64;
	}

	CHECK_TIME_END(run_time);
	printf("The runtime before using Strength Reduction is %.3f(ms).\n", run_time * 1000);

	CHECK_TIME_START;
	for (int i = 0; i < ARRAY_SIZE; i++) {
		Array[i] = i << 6 >> 6 << 6 >> 6 << 6 >> 6 << 6;
	}

	CHECK_TIME_END(run_time);
	printf("The runtime after using Strength Reduction is %.3f(ms).\n", run_time * 1000);
}

void Binary_Breakdown() {
	float Array_1[ARRAY_SIZE] = { 0, };
	float zero = 0, one = 0, two = 0, three = 0, four = 0, five = 0, six = 0, seven = 0;
	float run_time;
	int i = 0;
	printf("\n\n*****************************\n");
	printf("*       Binary Breakdown    *\n");
	printf("*****************************\n");

	srand(time(NULL));
	while (i < ARRAY_SIZE) {
		if (i < 50000)
			Array_1[i] = i % 4 + 4;
		else
			Array_1[i] = i % 8;

		i++;
	}

	i = 0;
	CHECK_TIME_START;
	while (i < ARRAY_SIZE) {
		if (Array_1[i] == 0)
			zero++;
		else if (Array_1[i] == 1)
			one++;
		else if (Array_1[i] == 2)
			two++;
		else if (Array_1[i] == 3)
			three++;
		else if (Array_1[i] == 4)
			four++;
		else if (Array_1[i] == 5)
			five++;
		else if (Array_1[i] == 6)
			six++;
		else if (Array_1[i] == 7)
			seven++;
		i++;
	}

	CHECK_TIME_END(run_time);
	printf("The runtime befor using Binary Breakdown is %.3f(ms).\n", run_time * 1000);


	i = 0;
	zero = 0, one = 0, two = 0, three = 0, four = 0, five = 0, six = 0, seven = 0;
	CHECK_TIME_START;
	while (i < ARRAY_SIZE) {
		if (Array_1[i] < 4) {
			if (Array_1[i] < 2) {
				if (Array_1[i] == 0)
					zero++;
				else if (Array_1[i] == 1)
					one++;
			}
			else {
				if (Array_1[i] == 2)
					two++;
				else if (Array_1[i] == 3)
					three++;
			}
		}
		else {
			if (Array_1[i] < 6) {
				if (Array_1[i] == 4)
					four++;
				else if (Array_1[i] == 5)
					five++;
			}
			else {
				if (Array_1[i] == 6)
					six++;
				else if (Array_1[i] == 7)
					seven++;
			}
		}
		i++;
	}
	CHECK_TIME_END(run_time);

	printf("The runtime after using Binary Breakdown is %.3f(ms)\n", run_time * 1000);

}


void Local_Global() {
	float Array_1[ARRAY_SIZE] = { 0, };
	float run_time;
	int i = 0;
	printf("\n\n*****************************\n");
	printf("*Use Local Instead of Global*\n");
	printf("*****************************\n");

	CHECK_TIME_START;
	while (i < ARRAY_SIZE) {
		Glob[i] = i;
		i++;
	}

	CHECK_TIME_END(run_time);
	printf("The runtime using global variable is %.3f(ms).\n", run_time * 1000);


	i = 0;
	CHECK_TIME_START;
	while (i < ARRAY_SIZE) {
		Array_1[i] = i;
		i++;
	}
	CHECK_TIME_END(run_time);

	printf("The runtime using local variable is %.3f(ms)\n", run_time * 1000);
}


void Loop_Inversion() {

	int Array_1[10000] = { 0, };
	int Array_2[10000] = { 0, };
	int Array_3[10000] = { 0, };
	int Array_4[10000] = { 0, };
	int i = 0;
	float run_time;
	printf("\n\n*****************************\n");
	printf("*       Loop Inversion      *\n");
	printf("*****************************\n");


	CHECK_TIME_START;

	while (i < 10000) {

		Array_1[i] = i;
		Array_2[i] = Array_1[i] + i;
		i++;
	}

	CHECK_TIME_END(run_time);
	printf("The runtime before using loop inversion is %.3f(ms).\n", run_time * 1000);

	i = 0;
	CHECK_TIME_START;

	if (i < 10000) {

		do {

			Array_3[i] = i;
			Array_4[i] = Array_3[i] + i;
			i++;
		} while (i < 10000);
	}
	CHECK_TIME_END(run_time);
	printf("The runtime after using loop inversion is %.3f(ms).\n", run_time * 1000);
}

void eliminating_sub_expressions() { // �ݺ��Ǵ� sub_expression�� ���� ����
	printf("\n\n*****************************\n");
	printf("*eliminating sub expressions*\n");
	printf("*****************************\n");
	float ret[100] = { 0, };
	float A, Y = 2;
	CHECK_TIME_START;
	
	for (int i = 0; i < 100; i++)

		ret[i] = pow(pow(Y, 5), 5) * Y;

//	float compute_time1, compute_time2;
	CHECK_TIME_END(compute_time1);
	printf("The runtime before using eliminating is %.3f(ms).\n", compute_time1 * 1000);


	CHECK_TIME_START;
	A = pow(Y, 5);

	for (int i = 0; i < 100; i++)

		ret[i] = pow(A, 5) * Y;

	CHECK_TIME_END(compute_time2);
	printf("The runtime before using eliminating is %.3f(ms).\n", compute_time2 * 1000);


	for (int i = 0; i < 100; i++) {

		if (ret[i] != pow(pow(Y, 5), 5) * Y) {

			printf("Values at index %d are not equal\n", i);

			return;
		}

	}
}

