#include "my_solver.h"

void program2_1()
{
	FILE* fp_r, *fp_w;
	__int64 start, freq, end;
	float resultTime = 0;

	fp_r = fopen("sampling_table.txt", "r");
	if (fp_r == NULL) {
		printf("input file not found....\n");
		exit(0);
	}

	fp_w = fopen("pdf_table.txt", "w");

	/***************************************************/
	int num;
	double h;
	fscanf(fp_r, "%d %lf", &num, &h);
	/*fprintf(fp_w, " x | x0 = 0.0 | ");
	for (int i = 1; i < num - 1; i++)
	{
		fprintf(fp_w, " x%d  |", i);
	}
	fprintf(fp_w, "\n");*/
	//printf("EEE");
	//printf("%d %lf str", num, h);
	double first_x, first_y;
	double x_cor[200];
	double y_cor[200];
	double new_x[200];
	double new_y[200];
	double sum_tmp = 0;
	for (int i = 0; i < num; i++)
	{

		fscanf(fp_r, "%lf %lf", &x_cor[i], &y_cor[i]);
		if (i == 0)
		{
			first_x = x_cor[0];
		}
		sum_tmp = sum_tmp + y_cor[i];
	}
	sum_tmp -= y_cor[0];
	sum_tmp -= y_cor[num - 1];
	
	double new_hh;
	double sadari[200];
	for (int i = 0; i < 2; i++)
	{
		new_x[i] = (x_cor[i] - first_x) / (x_cor[num - 1] - first_x);
	}
	
	new_hh = new_x[1] - new_x[0];
	// new_hh = (new_x[num-1] - new_x[0]) / num;
	fprintf(fp_w, " %d	%lf\n", num,new_hh );
	for (int i = 0; i < num; i++)
	{
		new_x[i] = (x_cor[i] - first_x) / (x_cor[num - 1] - first_x);
		sadari[i] = (((float)1 / num) / 2) * (y_cor[0] + y_cor[num - 1] + 2 * sum_tmp);
		new_y[i] = y_cor[i] / sadari[i];
		fprintf(fp_w, "%lf %lf\n",new_x[i], new_y[i]);
		//	printf("new_y[i] : %lf \n", new_y[i]);
	}
	/// //////////�ٽ� �����ؼ� 1���� Ȯ��////////////////

	double new_h = (new_x[num - 1] - new_x[0]) / num;  //new_x[1] - new_x[0];
	double sum_new = 0.0;
	for (int i = 1; i < num - 1; i++)
	{
		sum_new += new_y[i];
	}
	double answer;
	answer = (new_h / 2) * (new_y[0] + 2 * sum_new + new_y[num - 1]);
	//printf("answer : %lf\n", answer);
	/////////////////////////////////////////////////////////
	////0~0.25����
	double total = 0;
	sum_new = 0.0;
	int j = 1;
	int start_cor = j;

	while(new_x[j] < 0.25)
	{
		sum_new += new_y[j];
		j++;
	}

	answer = (new_h / 2) * (new_y[start_cor] + 2 * sum_new + new_y[j]);
	printf("Integrating the pdf from 0.0 to 0.25 = %lf\n", answer);
	total += answer;
	///////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////

	////0.25~0.50����
	sum_new = 0.0;
	start_cor = j;
	j++;
	while ( new_x[j] < 0.5)
	{
		sum_new += new_y[j];
		j++;
	}

	//double answer;
	answer = (new_h / 2) * (new_y[start_cor] + 2 * sum_new + new_y[j]);
	printf("Integrating the pdf from 0.25 to 0.50 = %lf\n", answer);
	total += answer;
	///////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////
	////0.50~0.75����
	sum_new = 0.0;
	start_cor = j;
	j++;
	while (new_x[j] < 0.75)
	{
		sum_new += new_y[j];
		j++;
	}
	
	//double answer;
	answer = (new_h / 2) * (new_y[start_cor] + 2 * sum_new + new_y[j]);
	printf("Integrating the pdf from 0.50 to 0.75 = %lf\n", answer);
	total += answer;
	start_cor = j;
	///////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////
	////0.75~1.00����
	sum_new = 0.0;
	start_cor = j;
	j++;
	while ( new_x[j] < 1)
	{
		sum_new += new_y[j];
		j++;
	}
	
	//double answer;
	answer = (new_h / 2) * (new_y[start_cor] + 2 * sum_new + new_y[j]);
	printf("Integrating the pdf from 0.75 to 1.0 = %lf\n", answer);
	total += answer;
	///////////////////////////////////////////////////////////////
	
	printf("total : %lf\n", total);

	/***************************************************/

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);
}
