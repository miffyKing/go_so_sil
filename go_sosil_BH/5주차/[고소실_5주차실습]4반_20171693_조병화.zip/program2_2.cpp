#include "my_solver.h"
#include <time.h>
#include <math.h>
#include <stdlib.h>

static unsigned long int next = 5000 ; // ??? = a positive integer
#define MY_RAND_MAX 32767
double bisec(double x0, double x1, double U);
int rand(void) {
	next = next * 1103515245 + 12345;
	return (unsigned int)(next / 65536) % (MY_RAND_MAX + 1);
}
double _f(double xm, double xm_1);
int num;
double x_cor[200];
double y_cor[200];
double new_x[200];
double new_y[200];
double integ_arr[200];

void program2_2()
{
	FILE* fp_r, *fp_w;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table.txt", "w");

	/***************************************************/
	
	double h;

	int nr;
	scanf("%d", &nr);
	fprintf(fp_w, "%d\n", nr);
	if (fp_r == NULL)
	{
		exit(0);
	}
	fscanf(fp_r, "%d %lf", &num, &h);
	for (int i = 0; i < num; i++)
	{
		fscanf(fp_r, "%lf %lf", &x_cor[i], &y_cor[i]);
	}
	/*
	for (int i = 0; i < 100; i++)
	{
		printf("%lf \n", (double)rand()/MY_RAND_MAX);
	}*/

	integ_arr[0] = 0;
	//integ_arr[1] = 1;

	for (int i = 1; i < num; i++)
	{
		integ_arr[i] = integ_arr[i - 1] + (y_cor[i - 1] + y_cor[i]) * h / 2;
	}
	for (int i = 0; i < num; i++)
	{
		//printf("integ value : %lf\n", integ_arr[i]);
		;
	}

	for (int i = 0; i < nr; i++)
	{
		int xm = 0;
		double result;
		double rand_val = (double) rand() / MY_RAND_MAX;
		result = bisec(0, 1, rand_val);	
		
		//printf("VALUE x: %lf\n", result);
		fprintf(fp_w, "%.15lf\n", result);
		//printf("rand val = %lf   xm    = %d\n", rand_val, xm);
		//integ_arr[xm] + 8page�� �ϸ� x0~xm���� ���а� ���ϱ� xm~x ���а� ������
		//
		//printf("xm is %d   new_x[] is %lf  rand_val is %lf\n", xm, x_cor[xm], rand_val);
		//printf("integ vealie %lf\n", integ_arr[28]);
		//printf("sik8 is %lf\n", sik8);
		//printf("�� ������ ���� �ᱹ  %lf\n", sik8 + integ_arr[xm]);
	}
	

	/***************************************************/

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);
}
double _f(double xm, double u)
{
	//xm������ ���� - u�� ���ϴ��Լ�
	
	// a ��� �غ��� �־�

	// xm = k*a + b;

	double k = x_cor[1] - x_cor[0];
	int i;
	for (i = 0;; i++) {
		if (k * i > xm)
			break;
	}
	i = i - 1;
	int n = xm / k;
	double sik8 = (y_cor[n] + ((y_cor[n + 1] - y_cor[n]) / (x_cor[n + 1] - x_cor[n])) * ((xm - x_cor[n]) / 2)) * (xm - x_cor[n]);

	double real_integ =  integ_arr[n] + sik8;
	return real_integ - u;
}

double bisec(double x0, double x1, double U) {
	// x0�� x1�� bisection �� �ϰ�
	// �Լ��� F(x) - U =0
	// �� ���� return �Ѵ�

	double result;
	int i;
	double mid, temp;

	for (i = 0; i < Nmax; i++)
	{
		mid = (x0 + x1) / 2;

		if (_f(x0, U) * _f(mid, U) < 0)
		{
			x1 = mid;
		}
		else
		{
			x0 = mid;
		}
		if (DELTA > fabs(_f(mid, U)))
		{
			//fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(_f(x1)));

			break;
		}
		if (i > 0) {
			if (fabs(temp - mid) < EPSILON)
			{
				//fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(_f(x1)));

				break;
			}
		}
		temp = mid;;

	}

	result = mid;

	return result;

}
/*
while (1)
{
	

	fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(_f(x1)));
	if (_f(a0) * _f(x1) < 0)
	{
		b0 = x1;
	}
	else
	{
		a0 = x1;
	}
	if (DELTA > fabs(_f(x1)))
	{
		fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(_f(x1)));

		break;
	}
	if (fabs(x0 - x1) < EPSILON)
	{
		fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(_f(x1)));

		break;
	}
	if (n > Nmax)
	{
		fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(_f(x1)));

		break;
	}
	x0 = x1;
	n++;
}*/