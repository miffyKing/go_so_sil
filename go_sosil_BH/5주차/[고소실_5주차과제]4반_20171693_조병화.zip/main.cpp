﻿#include "my_solver.h"

int main() {
   program2_1(); // make pdf table
   program2_2(); // create random number

  //  printf("It is result of program2_4\n");
   program_hw2_1();

  //  printf("It is result of program2_2_a\n");
   program2_2_a();
  //  printf("It is result of program2_2_b\n");
   program2_2_b(); //secant
   // printf("It is result of program2_2_c\n");
   program2_2_c(); //newton

  //  printf("It is result of program2_3\n");
   program2_3();
    //program2_3(); // HOMEWORK
}
