#include "my_solver.h"
#include <time.h>
#include <math.h>
#include <stdlib.h>

// HOMEWORK
static unsigned long int next = 5000; // ??? = a positive integer
#define MY_RAND_MAX 32767
double bisec2(double x0, double x1, double U);
double _f2_bisec(double xm, double xm_1);

double _f1_sec(double x1, double** table, int num, double* integral, double u); //secant
double _fp1_new(double x0, double** table, int num, double u); //newton
double _f1_new(double x1, double** table, int num, double* integral, double u); //newton
int my_rand2(void) {
	next = next * 1103515245 + 12345;
	return (unsigned int)(next / 65536) % (MY_RAND_MAX + 1);
}
void program_hw2_1()
{
	double lambda[3] = { 2.0, 5.0, 7.0 };
	int n_r;
	int i, j;
	double a, b, ya, yb, x0, x1, U;
	double temp, E, Var;
	double* root;

	double avg_sum = 0;
	double vari_sum = 0;
	srand(time(NULL));
	printf("\nbeginning of program hw2_1. homework 2-1\n");
//	printf("������ ���� ������ �Է��Ͻÿ�. : ");
	//for (int scan_num = 0; scan_num < 3; scan_num++)
	int scan_num = 0;

		scan_num++;
		printf("������ ������ ������ �Է��Ͻÿ�. : ");
		scanf("%d", &n_r);
	
		//printf("result of %d th input. making %d random numbers \n", scan_num, n_r);
		root = (double*)malloc(sizeof(double) * n_r);

		for (int z = 0; z < 3; z++) {
			for (i = 0; i < n_r; i++) {
				U = (double)rand() / RAND_MAX; // [0, 1] ���̿� �����ϴ� ������ �� U
				a = 0.0, b = 10000.0;
				x0 = 100.0;
				x1 = (a + b) / 2.0;
				//x1 = a+1;
				for (int n = 0; ; n++) {
					if (fabs((1 - exp((-1) * lambda[z] * x1)) - U) < DELTA)
						break;
					if (n >= Nmax)
						break;
					if (fabs(x0 - x1) < EPSILON)
						break;

					temp = (1 - exp((-1) * lambda[z] * x1)) - U;
					ya = (1 - exp((-1) * lambda[z] * a)) - U;
					yb = (1 - exp((-1) * lambda[z] * b)) - U;
					if (ya * temp < 0) {
						b = x1;
						//yb = temp;
					}
					else if (yb * temp < 0) {
						a = x1;
						//ya = temp;
					}

					x0 = x1;
					x1 = (a + b) / 2.0;
				}
				root[i] = x1;
			}
			//E = get_avg(root, n_r);
		//Var = get_var(root, n_r, E);

			for (int i = 0; i < n_r; i++)
			{
				avg_sum += root[i];
			}
			E = avg_sum / (double)(n_r - 1);

			for (int i = 0; i < n_r; i++)
			{
				vari_sum += pow(root[i] - E, 2);
			}
			Var = vari_sum / (double)n_r;

			printf("lambda %lf : \n", lambda[z]);
			printf("Average : %lf		Variance : %lf\n", E, Var);
			printf("Avg Diff : %lf		Var Diff : %lf\n", fabs(1.0 / lambda[z] - E), fabs((1.0 / (lambda[z] * lambda[z])) - Var));
			printf("\n");
			avg_sum = 0; vari_sum = 0;
		}
	
}
// HOMEWORK
//double _f(double xm, double xm_1);
int num2;
double x_cor2[200];
double y_cor2[200];
double new_x2[200];
double new_y2[200];
double integ_arr2[200];

void program2_2_a()
{
	__int64 start, freq, end;
	float resultTime = 0;

	/***************************************************/
	double h;
	int nr;
	printf("\nbeginning program2_2_a. BISECTION method ..\n ");
	printf("���� ������ �Է��Ͻÿ� : ");
	scanf("%d", &nr);
	

	CHECK_TIME_START;
	FILE* fp_r, * fp_w;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table.txt", "w");
	fprintf(fp_w, "%d\n", nr);
	if (fp_r == NULL)
	{
		exit(0);
	}
	fscanf(fp_r, "%d %lf", &num2, &h);
	for (int i = 0; i < num2; i++)
	{
		fscanf(fp_r, "%lf %lf", &x_cor2[i], &y_cor2[i]);
	}
	integ_arr2[0] = 0;
	for (int i = 1; i < num2; i++)
	{
		integ_arr2[i] = integ_arr2[i - 1] + (y_cor2[i - 1] + y_cor2[i]) * h / 2;
	}
	for (int i = 0; i < num2; i++)
	{
		;//printf("integ value : %lf\n", integ_arr[i]);
	}
	for (int i = 0; i < nr; i++)
	{
		int xm = 0;
		double result;
		double rand_val = (double)my_rand2() / MY_RAND_MAX;
		result = bisec2(0, 1, rand_val);
		fprintf(fp_w, "%.15lf\n", result);
	}
	/*************************************************0**/
	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);
	// something to do...

	CHECK_TIME_END(resultTime);

	printf("The program2_2_a run time is %f(ms)..\n\n", resultTime * 1000.0);
}
double _f2_bisec(double xm, double u)
{
	//xm������ ���� - u�� ���ϴ��Լ�
	// a ��� �غ��� ��
	// xm = k*a + b;
	double k = x_cor2[1] - x_cor2[0];
	int i;
	for (i = 0;; i++) {
		if (k * i > xm)
			break;
	}
	i = i - 1;
	int n = xm / k;
	double sik8 = (y_cor2[n] + ((y_cor2[n + 1] - y_cor2[n]) / (x_cor2[n + 1] - x_cor2[n])) * ((xm - x_cor2[n]) / 2)) * (xm - x_cor2[n]);
	double real_integ = integ_arr2[n] + sik8;
	return real_integ - u;
}

double bisec2(double x0, double x1, double U) {
	// x0�� x1�� bisection �� �ϰ�
	// �Լ��� F(x) - U =0
	// �� ���� return �Ѵ�
	double result;
	int i;
	double mid, temp;
	//for (i = 0; i < Nmax; i++)
	i = 0;
	//while(1)
	for(int i =0; i< Nmax; i++)
	{
		mid = (x0 + x1) / 2;
		if (_f2_bisec(x0, U) * _f2_bisec(mid, U) < 0)
		{
			x1 = mid;
		}
		else
		{
			x0 = mid;
		}
		if (DELTA > fabs(_f2_bisec(mid, U)))
		{
			//fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(_f(x1)));
			break;
		}
		if (i > 0) {
			if (fabs(temp - mid) < EPSILON)
			{
				//fprintf(fp, "%d  %20.18e   %20.18e\n", n + 1, x0, fabs(_f(x1)));
				break;
			}
		}
		//if (i > Nmax) {
		//		break;
		//	}
		temp = mid;;
		i++;
	}
	result = mid;
	return result;
}

void program2_2_b()   //secant method
{
	__int64 start, freq, end;
	float resultTime = 0;


	FILE* fp_r, * fp_w;
	int n_r, num, n;
	double h, u;
	double a, b, before, now, temp;
	double x0, x1;
	double** table, * integral;
	double* x_var;
	double* y_var;
	
	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table2_2_b.txt", "w");
	printf("beiginning of program 2_2_b . SECANT method ..\n");

	printf("���� ������ �Է��Ͻÿ� : ");
	scanf("%d", &n_r);
	fprintf(fp_w, "%d\n", n_r);
	fscanf(fp_r, "%d %lf", &num, &h);


	integral = (double*)malloc(sizeof(double) * num);
	table = (double**)malloc(sizeof(double*) * num);
	srand(time(NULL));

	CHECK_TIME_START;


	for (int i = 0; i < num; i++) {
		table[i] = (double*)malloc(sizeof(double) * 2);

	}
	for (int i = 0; i < num; i++) {
		fscanf(fp_r, "%lf %lf", &table[i][0], &table[i][1]);
		//fscanf(fp_r, "%lf %lf", &x_var[i], &y_var[i]);

	}

	integral[0] = 0;
	for (int i = 1; i < num2; i++)
	{
		integral[i] = integral[i - 1] + (table[i - 1][1] + table[i][1]) * h / 2;
	}
	for (int i = 0; i < n_r; i++) {
		u = (double)rand() / RAND_MAX;

		a = 0.0;
		b = 1.0;
		x1 = a+ (b-a)/2.0;
		
		x0 =0;
		n = 0;

		//while (1) {
		//for(int n =0; n< Nmax; n++)
		while (1)
		{
			if (_f1_sec(a, table, num, integral, u) * _f1_sec(x1, table, num, integral, u) < 0) {
				b = x1;
			}
			else {
				a = x1;
			}

			if (fabs(_f1_sec(x1, table, num, integral, u)) < DELTA) {
				break;
			}
			if (n > Nmax) {
				break;
			}
			if (fabs(x0 - x1) < EPSILON) {
				break;
			}
			x0 = x1;
			x1 = a + (b - a) / 2.0;
			n++;
		}

		if (fabs(_f1_sec(x1, table, num, integral, u)) < DELTA) {
			fprintf(fp_w, "%.15lf\n", x1);
			continue;
		}
		if (fabs(x0 - x1) < EPSILON) {

			fprintf(fp_w, "%.15lf\n", x1);
			continue;
		}

		n = 0;

		while (1)
		{
			if (fabs(_f1_sec(x1, table, num, integral, u)) < DELTA) {
				break;
			}
			if (n >= Nmax) {
				break;
			}
			if (fabs(x0 - x1) < EPSILON) {
				break;
			}
			temp = x0;
			x0 = x1;

			x1 = x1 - _f1_sec(x1, table, num, integral, u) * ((x1 - temp) / (_f1_sec(x1, table, num, integral, u) - _f1_sec(temp, table, num, integral, u)));
			n++;

			if (x1 > 1.0)
				x1 = 1.0;
		}
		fprintf(fp_w, "%.15lf\n", x1);

	}

	CHECK_TIME_END(resultTime);

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);

	printf("The program2_2_b run time is %f(ms)..\n", resultTime * 1000.0);
	
}
double _f1_sec(double x1, double** table, int num, double* integral, double u) 
{
	int i;
	double result = 0.0;

	for (i = 0; i < num - 1; i++) {
		if (table[i][0] > x1)
			break;
	}
	if (i == num - 1)
		i--;
	result = integral[i] + (integral[i + 1] - integral[i]) * ((x1 - table[i][0]) / (table[i + 1][0] - table[i][0]));
	result = result - u;
	return result;
}

void program2_2_c()    // newton
{
	__int64 start, freq, end;
	FILE* fp_r, * fp_w;
	float resultTime = 0;
	int n_r, num, n;
	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table2_2_c.txt", "w");
	double h, u;
	double a, b, before, now, temp;
	double x0, x1;
	double** table, * integral;
	double* x_var;
	double* y_var;

	printf("\nbeginning of program2_2_c. Newton methon\n");
	printf("���� ������ �Է��Ͻÿ� : ");
	scanf("%d", &n_r);
	fprintf(fp_w, "%d\n", n_r);
	fscanf(fp_r, "%d %lf", &num, &h);
	srand(time(NULL));
	

	CHECK_TIME_START;

	integral = (double*)malloc(sizeof(double) * num);
	table = (double**)malloc(sizeof(double*) * num);
	//printf("DDDDD\n");
	//printf("%d    %lf    \n", num , h);

	for (int i = 0; i < num; i++) {
		table[i] = (double*)malloc(sizeof(double) * 2);

	}
	for (int i = 0; i < num; i++) {
		fscanf(fp_r, "%lf %lf", &table[i][0], &table[i][1]);
		//fscanf(fp_r, "%lf %lf", &x_var[i], &y_var[i]);
	}

	integral[0] = 0;
	for (int i = 1; i < num2; i++)
	{
		integral[i] = integral[i - 1] + (table[i - 1][1] + table[i][1]) * h / 2;
	}


	for (int i = 0; i < n_r; i++) {
		u = (double)rand() / RAND_MAX;

		a = 0.0;
		b = 1.0;
		x1 = u;
		x0 = 1;
		n = 0;
		
		for( n=0; n<Nmax; n++)
		{
			//printf("))))))))\n");
			if (fabs(_f1_new(x1, table, num, integral, u)) < DELTA) {
				break;
			}
			if (fabs(x0 - x1) < EPSILON) {
				break;
			}

			x0 = x1;
			x1 = x0 - _f1_new(x0, table, num, integral, u) / _fp1_new(x0, table, num, u);
			n++;

			if (x1 > 1.0)
				x1 = 1.0;
		}
		fprintf(fp_w, "%.15lf\n", x1);

	}
	// something to do...

	CHECK_TIME_END(resultTime);
	
	if (fp_w != NULL) fclose(fp_w);
	if (fp_r != NULL) fclose(fp_r);

	printf(" The program2_2_c run time is %f(ms)..\n", resultTime * 1000.0);

}

double _fp1_new(double x0, double** table, int num, double u) {
	int i;
	double result = 0.0;
	double s;

	for (i = 0; i < num - 1; i++) {
		if (table[i][0] > x0)
			break;
	}
	if (i == num - 1)
		i--;

	s = (x0 - table[i][0]) / (table[i + 1][0] - table[i][0]);
	//printf("%lf\n", s);
	result = table[i][1] * (1.0 - s) + (table[i + 1][1] * s);

	return result;
}
double _f1_new(double x1, double** table, int num, double* integral, double u) {
	int i;
	double res_value = 0.0;

	for (i = 0; i < num - 1; i++) {
		if (table[i][0] > x1)
			break;
	}
	
	if (i == num - 1)
		i--;
	res_value = integral[i] + (integral[i + 1] - integral[i]) * ((x1 - table[i][0]) / (table[i + 1][0] - table[i][0]));

	return res_value - u;
}

void program2_3()
{
	FILE* fp_pdf, * fp_random, * fp_random2, *fp_random3;
	FILE* fp_histo , *fp_histo2, *fp_histo3;

	double pdf_h;
	int* histo_range;
	fp_pdf = fopen("pdf_table.txt", "r");
	fp_random = fopen("random_event_table2_2_b.txt", "r");
	fp_random2 = fopen("random_event_table.txt", "r");
	//fp_random = fopen("random_event_table.txt", "r");
	
	printf("\n\nbeginning program2_3 making histogram\n");

	printf("\n\nmaking histogram using BISECTiON...\n");
	printf("making histogram using SECANT...\n");
	printf("making histogram using NEWTON...\n");
	fp_histo = fopen("histogram_2_3_bisection.txt", "w");
	

	if (fp_pdf == NULL) {
		printf("input file not found....33\n");
		exit(-1);
	}if (fp_random == NULL) {
		printf("input file not found....44\n");
		exit(-1);
	}
	if (fp_random2 == NULL) {
		printf("input file not found....44\n");
		exit(-1);
	}
	int pdf_num, random_num;


	/////////////////////////////////secant method////////////////////////
	fscanf(fp_pdf, "%d %lf", &pdf_num, &pdf_h);
	fscanf(fp_random, "%d", &random_num);

	//printf("!!!!!!!!\n");
	histo_range = (int*)malloc(sizeof(int) * pdf_num);
	for (int i = 0; i < pdf_num; i++)
	{
		histo_range[i] = 0;
	}  // pdfũ�⸸ŭ ���� �迭�� ����� 0���� �ʱ�ȭ ����

	for (int i = 0; i < random_num; i++)
	{
		double rand_val;
		int abs_rand_val;

		fscanf(fp_random, "%lf", &rand_val);
		rand_val *= 100; // 43.0743... �� �÷� �ٲ㼭
		abs_rand_val = (int)rand_val;
		histo_range[abs_rand_val]++;
	}
	for (int i = 0; i < pdf_num; i++)
	{
		fprintf(fp_histo, "%d  %d\n", i, histo_range[i]);
	}
	if (fp_pdf != NULL) fclose(fp_pdf);
	if (fp_random != NULL) fclose(fp_random);
	if (fp_histo != NULL) fclose(fp_histo);
	////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////bisection//////////////////////////////////////////

	fp_pdf = fopen("pdf_table.txt", "r");
	fp_random = fopen("random_event_table2_2_b.txt", "r");
	fp_random2 = fopen("random_event_table.txt", "r");
	fp_histo2 = fopen("histogram_2_3_secant.txt", "w");

	fscanf(fp_pdf, "%d %lf", &pdf_num, &pdf_h);
	fscanf(fp_random2, "%d", &random_num);

	//printf("!!!!!!!!\n");
	histo_range = (int*)malloc(sizeof(int) * pdf_num);
	for (int i = 0; i < pdf_num; i++)
	{
		histo_range[i] = 0;
	}  // pdfũ�⸸ŭ ���� �迭�� ����� 0���� �ʱ�ȭ ����
	
	for (int i = 0; i < random_num; i++)
	{
		double rand_val;
		int abs_rand_val;

		fscanf(fp_random2, "%lf", &rand_val);

		rand_val *= 100; // 43.0743... �� �÷� �ٲ㼭
		
		abs_rand_val = (int)rand_val;
		histo_range[abs_rand_val]++;
	}

	//printf("!!!!!!!!\n");
	for (int i = 0; i < pdf_num; i++)
	{
		fprintf(fp_histo, "%d  %d\n", i, histo_range[i]);
	}

	if (fp_pdf != NULL) fclose(fp_pdf);
	if (fp_random != NULL) fclose(fp_random);
	if (fp_histo != NULL) fclose(fp_histo);
	

	////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////bisection//////////////////////////////////////////

	fp_pdf = fopen("pdf_table.txt", "r");
	//fp_random = fopen("random_event_table2_2_c.txt", "r");
	fp_random3 = fopen("random_event_table.txt", "r");

	fp_histo3 = fopen("histogram_2_3_newton.txt", "w");

	fscanf(fp_pdf, "%d %lf", &pdf_num, &pdf_h);
	fscanf(fp_random3, "%d", &random_num);

	//printf("!!!!!!!!\n");
	histo_range = (int*)malloc(sizeof(int) * pdf_num);
	for (int i = 0; i < pdf_num; i++)
	{
		histo_range[i] = 0;
	}  // pdfũ�⸸ŭ ���� �迭�� ����� 0���� �ʱ�ȭ ����
	//printf("random num : %d\n", random_num);

	//printf("!!!!!!!!\n");
	for (int i = 0; i < random_num; i++)
	{
		double rand_val;
		int abs_rand_val;

		fscanf(fp_random3, "%lf", &rand_val);

		rand_val *= 100; // 43.0743... �� �÷� �ٲ㼭
		//printf("rand_val is %lf\n", rand_val);
		//printf("abs_rand_val = %d\n", rand_val);

		abs_rand_val = (int)rand_val;
		//		printf("abs_rand_val = %d\n", abs_rand_val);
				//printf("rand val in abs is %d\n", abs_rand_val);
		histo_range[abs_rand_val]++;
	}

	//printf("!!!!!!!!\n");
	for (int i = 0; i < pdf_num; i++)
	{
		fprintf(fp_histo3, "%d  %d\n", i, histo_range[i]);
	}

	if (fp_pdf != NULL) fclose(fp_pdf);
	if (fp_random3 != NULL) fclose(fp_random);
	if (fp_histo3 != NULL) fclose(fp_histo);
	printf("making histogram complete!\n");

}